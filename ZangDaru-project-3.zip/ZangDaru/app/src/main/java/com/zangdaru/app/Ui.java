package com.zangdaru.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.InputStream;
import java.util.Locale;

final class Ui {
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    static final class Pal {
        final int bg, primary, soft, text;
        Pal(int bg, int primary, int soft, int text) {
            this.bg = bg; this.primary = primary; this.soft = soft; this.text = text;
        }
    }

    // صورتی، نعنایی، سفید، آبی، سبز
    static final String[] THEME_NAMES = {"صورتی", "نعنایی", "سفید", "آبی", "سبز"};
    static final int[] DOTS = {0xFFF48FB1, 0xFF80E0C0, 0xFFFFFFFF, 0xFF64B5F6, 0xFF81C784};
    static final Pal[] PALS = {
        new Pal(0xFFFFF1F6, 0xFFE0558A, 0xFFFFD9E6, 0xFF4A1F33),
        new Pal(0xFFEEFBF5, 0xFF2FAE8A, 0xFFC9F1E2, 0xFF174536),
        new Pal(0xFFFFFFFF, 0xFF607D8B, 0xFFECEFF1, 0xFF263238),
        new Pal(0xFFEEF6FF, 0xFF2878C8, 0xFFCFE4FA, 0xFF11365E),
        new Pal(0xFFF1F9EC, 0xFF3E9A43, 0xFFD3EDCB, 0xFF1B4B1E)
    };

    static Pal pal(Context c) { return PALS[Store.theme(c)]; }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable box(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static Button button(Context c, String s, int bg, int fg) {
        Button b = new Button(c);
        b.setText(s);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setBackground(box(c, bg, 16));
        b.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14));
        return b;
    }

    static LinearLayout.LayoutParams lp(Context c, int w, int h, float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(c, topDp);
        return p;
    }

    /** Sets content, forces right-to-left layout and tints the status bar. */
    static void apply(Activity a, View content) {
        a.setContentView(content);
        a.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        a.getWindow().setStatusBarColor(pal(a).primary);
    }

    static String hm(int h, int m) { return String.format(Locale.US, "%02d:%02d", h, m); }

    static String fa(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) sb.append(ch >= '0' && ch <= '9' ? (char) ('\u06F0' + (ch - '0')) : ch);
        return sb.toString();
    }

    static Bitmap decodeUri(Context c, Uri uri, int max) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = c.getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int s = 1;
            while (o.outWidth / (s * 2) >= max || o.outHeight / (s * 2) >= max) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            in = c.getContentResolver().openInputStream(uri);
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            int rot = 0;
            in = c.getContentResolver().openInputStream(uri);
            try {
                ExifInterface ex = new ExifInterface(in);
                int ori = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
                if (ori == 6) rot = 90; else if (ori == 3) rot = 180; else if (ori == 8) rot = 270;
            } catch (Exception e) { /* no exif */ } finally { in.close(); }
            if (b != null && rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            }
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    static Bitmap decodeFile(String path, int max) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            int s = 1;
            while (o.outWidth / (s * 2) >= max || o.outHeight / (s * 2) >= max) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            return BitmapFactory.decodeFile(path, o2);
        } catch (Exception e) {
            return null;
        }
    }

    /** Title bar with a back arrow (arrow points right because the layout is right-to-left). */
    static LinearLayout topBar(final Activity a, String title) {
        Pal p = pal(a);
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.setBackground(box(a, p.primary, 20));
        bar.setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 10));
        TextView back = text(a, "→", 30, Color.WHITE, true);
        back.setPadding(dp(a, 8), 0, dp(a, 16), 0);
        back.setOnClickListener(v -> a.finish());
        bar.addView(back);
        bar.addView(text(a, title, 22, Color.WHITE, true));
        return bar;
    }

    /** Shows a dialog with right-to-left layout. */
    static AlertDialog show(AlertDialog.Builder b) {
        AlertDialog d = b.show();
        d.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return d;
    }

    static final int WHITE = Color.WHITE;
}
