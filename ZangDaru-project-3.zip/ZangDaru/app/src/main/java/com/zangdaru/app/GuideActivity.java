package com.zangdaru.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class GuideActivity extends Activity {
    private static final String[][] STEPS = {
        {"💊  افزودن دارو",
         "در صفحه‌ی اصلی روی «افزودن داروی جدید» بزنید. نام دارو را بنویسید و با «گرفتن عکس» یا «از گالری» عکس دارو را اضافه کنید. هنگام زنگ، همین عکس نمایش داده می‌شود."},
        {"🕐  ساعت مصرف",
         "«افزودن ساعت» را بزنید و ساعت مصرف را انتخاب کنید. اگر دارو چند بار در روز مصرف می‌شود، چند ساعت اضافه کنید."},
        {"📅  مدت مصرف",
         "یکی از گزینه‌ها را انتخاب کنید: یک هفته، دو هفته یا یک ماه (هر روز). اگر دارو فقط در چند روز مشخص مصرف می‌شود، مثلاً هفته‌ای یک بار، گزینه‌ی «روزهای انتخابی از تقویم» را بزنید. سپس یا روزها را در تقویم شمسی لمس کنید، یا «هر هفته در یک روز مشخص» را بزنید تا روزها خودکار انتخاب شوند."},
        {"⏰  وقتی زنگ می‌خورد",
         "عکس و نام دارو روی صفحه می‌آید. بعد از خوردن دارو «مصرف کردم» را بزنید. اگر نمی‌توانید، «۱۰ دقیقه بعد» زنگ را دوباره می‌آورد."},
        {"🩺  مراجعه به پزشک",
         "در صفحه‌ی اصلی «پزشک» را بزنید و «ثبت وقت پزشک» را انتخاب کنید. نام پزشک، روز (از تقویم) و ساعت را وارد کنید. ۲۴ ساعت قبل و ۲ ساعت قبل از وقت، زنگ یادآوری می‌خورد."},
        {"🗓  تقویم شمسی",
         "«تقویم» تمام روزهای سال را نشان می‌دهد. روزهای مصرف دارو سبز و روزهای مراجعه به پزشک نارنجی هستند و امروز با کادر مشخص شده است. روی هر روز بزنید تا داروها و وقت‌های همان روز را ببینید. با «سال قبل» و «سال بعد» سال را عوض کنید."},
        {"🎨  تغییر رنگ",
         "«تنظیمات» را بزنید و یکی از رنگ‌های صورتی، نعنایی، سفید، آبی یا سبز را انتخاب کنید."},
        {"✏️  ویرایش و حذف",
         "روی هر دارو یا وقت پزشک بزنید تا تغییرش بدهید یا حذفش کنید. در صفحه‌ی ویرایش دارو دکمه‌ی «آزمایش زنگ» هست."},
        {"📆  تقویم گوشی",
         "از «تنظیمات ← اتصال به تقویم گوشی» اجازه‌ی تقویم را بدهید. بعد داروها و وقت‌های پزشک در تقویم گوشی هم ثبت می‌شوند. برای وقت پزشک، ۲۴ ساعت و ۲ ساعت قبل هشدار هم در تقویم گوشی و هم زنگ خود برنامه فعال می‌شود. در صفحه‌ی ویرایش وقت پزشک دکمه‌ی «آزمایش زنگ» هست."},
        {"⚠️  نکته‌های مهم",
         "• اجازه‌ی نمایش اعلان‌ها را به برنامه بدهید.\n• صدای «آلارم» گوشی را بلند کنید (حالت بی‌صدا هم زنگ را قطع نمی‌کند، ولی صدای آلارم صفر نباشد).\n• در تنظیمات باتری، برنامه را «بدون محدودیت» بگذارید.\n• گوشی را در طول روز کاملاً خاموش نکنید.\n• این برنامه فقط یادآور است و جایگزین توصیه‌ی پزشک نیست."}
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.Pal p = Ui.pal(this);
        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad * 2);
        sv.addView(col);
        col.addView(Ui.topBar(this, "راهنمای استفاده"), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));
        for (String[] s : STEPS) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(Ui.box(this, p.soft, 20));
            card.setPadding(pad, pad, pad, pad);
            card.addView(Ui.text(this, s[0], 21, p.primary, true));
            TextView body = Ui.text(this, s[1], 18, p.text, false);
            body.setLineSpacing(0, 1.25f);
            card.addView(body, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));
            col.addView(card, Ui.lp(this, Ui.MATCH, Ui.WRAP, 14));
        }
        Ui.apply(this, sv);
    }
}
